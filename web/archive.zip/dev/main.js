// modules are defined as an array
// [ module function, map of requires ]
//
// map of requires is short require name -> numeric require
//
// anything defined in a previous bundle is accessed via the
// orig method which is the require for previous bundles
parcelRequire = (function (modules, cache, entry, globalName) {
  // Save the require from previous bundle to this closure if any
  var previousRequire = typeof parcelRequire === 'function' && parcelRequire;
  var nodeRequire = typeof require === 'function' && require;

  function newRequire(name, jumped) {
    if (!cache[name]) {
      if (!modules[name]) {
        // if we cannot find the module within our internal map or
        // cache jump to the current global require ie. the last bundle
        // that was added to the page.
        var currentRequire = typeof parcelRequire === 'function' && parcelRequire;
        if (!jumped && currentRequire) {
          return currentRequire(name, true);
        }

        // If there are other bundles on this page the require from the
        // previous one is saved to 'previousRequire'. Repeat this as
        // many times as there are bundles until the module is found or
        // we exhaust the require chain.
        if (previousRequire) {
          return previousRequire(name, true);
        }

        // Try the node require function if it exists.
        if (nodeRequire && typeof name === 'string') {
          return nodeRequire(name);
        }

        var err = new Error('Cannot find module \'' + name + '\'');
        err.code = 'MODULE_NOT_FOUND';
        throw err;
      }

      localRequire.resolve = resolve;
      localRequire.cache = {};

      var module = cache[name] = new newRequire.Module(name);

      modules[name][0].call(module.exports, localRequire, module, module.exports, this);
    }

    return cache[name].exports;

    function localRequire(x){
      return newRequire(localRequire.resolve(x));
    }

    function resolve(x){
      return modules[name][1][x] || x;
    }
  }

  function Module(moduleName) {
    this.id = moduleName;
    this.bundle = newRequire;
    this.exports = {};
  }

  newRequire.isParcelRequire = true;
  newRequire.Module = Module;
  newRequire.modules = modules;
  newRequire.cache = cache;
  newRequire.parent = previousRequire;
  newRequire.register = function (id, exports) {
    modules[id] = [function (require, module) {
      module.exports = exports;
    }, {}];
  };

  var error;
  for (var i = 0; i < entry.length; i++) {
    try {
      newRequire(entry[i]);
    } catch (e) {
      // Save first error but execute all entries
      if (!error) {
        error = e;
      }
    }
  }

  if (entry.length) {
    // Expose entry point to Node, AMD or browser globals
    // Based on https://github.com/ForbesLindesay/umd/blob/master/template.js
    var mainExports = newRequire(entry[entry.length - 1]);

    // CommonJS
    if (typeof exports === "object" && typeof module !== "undefined") {
      module.exports = mainExports;

    // RequireJS
    } else if (typeof define === "function" && define.amd) {
     define(function () {
       return mainExports;
     });

    // <script>
    } else if (globalName) {
      this[globalName] = mainExports;
    }
  }

  // Override the current require with this new one
  parcelRequire = newRequire;

  if (error) {
    // throw error from earlier, _after updating parcelRequire_
    throw error;
  }

  return newRequire;
})({"cscv":[function(require,module,exports) {
var define;
!function (t, e) {
  "object" == typeof exports && "undefined" != typeof module ? module.exports = e() : "function" == typeof define && define.amd ? define(e) : (t = t || self).Swiper = e();
}(this, function () {
  "use strict";

  function e() {
    return (e = Object.assign || function (t) {
      for (var e = 1; e < arguments.length; e++) {
        var i = arguments[e];

        for (var s in i) Object.prototype.hasOwnProperty.call(i, s) && (t[s] = i[s]);
      }

      return t;
    }).apply(this, arguments);
  }

  function c(e, t) {
    void 0 === t && (t = []), Array.isArray(t) || (t = [t]), t.forEach(function (t) {
      return !e.classList.contains(t) && e.classList.add(t);
    });
  }

  function u(e, t) {
    void 0 === t && (t = []), Array.isArray(t) || (t = [t]), t.forEach(function (t) {
      return e.classList.contains(t) && e.classList.remove(t);
    });
  }

  function d(t, e) {
    var i,
        s = getComputedStyle(t).transform.replace(/[a-z]|\(|\)|\s/g, "").split(",").map(parseFloat);
    return 16 === s.length ? i = s.slice(12, 14) : 6 === s.length && (i = s.slice(4, 6)), i[e ? 0 : 1] || 0;
  }

  var n = ["INPUT", "SELECT", "OPTION", "TEXTAREA", "BUTTON", "VIDEO"];
  return function () {
    function s(t, e) {
      e = s.formatConfig(e), this.index = 0, this.scrolling = !1, this.config = e, this.supportTouch = Boolean("ontouchstart" in window || 0 < window.navigator.maxTouchPoints || 0 < window.navigator.msMaxTouchPoints || window.DocumentTouch && document instanceof DocumentTouch), "string" == typeof t && (t = document.body.querySelector(t)), this.$el = t, this.$wrapper = t.querySelector("." + e.wrapperClass), this.eventHub = {}, this.initPlugins(e.plugins), this.emit("before-init", this), this.initListener(), this.initTouchStatus(), this.initWheelStatus(), this.update(), this.attachListener(), this.emit("after-init", this), this.scroll(e.initialSlide);
    }

    var t = s.prototype;
    return t.initPlugins = function (t) {
      var e = this;
      (t || []).forEach(function (t) {
        return t(e);
      });
    }, t.on = function (t, e) {
      var i = this.eventHub;
      i[t] ? i[t].push(e) : i[t] = [e];
    }, t.off = function (t, e) {
      var i = this.eventHub;

      if (i[t]) {
        var s = i[t].indexOf(e);
        -1 < s && i[t].splice(s, 1);
      }
    }, t.emit = function (t) {
      for (var e = arguments.length, i = new Array(1 < e ? e - 1 : 0), s = 1; s < e; s++) i[s - 1] = arguments[s];

      var n = this.eventHub;
      n[t] && n[t].forEach(function (t) {
        return t.apply(void 0, i);
      });
    }, t.initListener = function () {
      var a = this,
          r = this.$wrapper,
          h = this.config,
          l = this.supportTouch;
      this.listeners = {
        handleTouchStart: function (t) {
          for (var e = 0; e < h.excludeElements.length; e++) if (h.excludeElements[e].contains(t.target)) return;

          a.initTouchStatus();
          var i = a.touchStatus,
              s = h.touchStartPreventDefault && -1 === n.indexOf(t.target.nodeName) || h.touchStartForcePreventDefault;
          i.startOffset = d(r, a.isHorizontal), a.transform(i.startOffset), r.style.transition = "none", i.isTouchStart = !0, i.touchStartTime = Date.now(), i.touchTracks.push({
            x: l ? t.touches[0].pageX : t.pageX,
            y: l ? t.touches[0].pageY : t.pageY
          }), s && !h.passiveListeners && t.preventDefault();
        },
        handleTouchMove: function (t) {
          var e = a.touchStatus,
              i = e.touchTracks;

          if (e.isTouchStart && !e.isScrolling) {
            h.touchMoveStopPropagation && t.stopPropagation();
            var s = {
              x: l ? t.touches[0].pageX : t.pageX,
              y: l ? t.touches[0].pageY : t.pageY
            },
                n = {
              x: s.x - i[i.length - 1].x,
              y: s.y - i[i.length - 1].y
            };
            i.push(s);
            var o = 180 * Math.atan2(Math.abs(n.y), Math.abs(n.x)) / Math.PI,
                r = 0;
            a.isHorizontal ? o < h.touchAngle || e.isTouching ? (e.isTouching = !0, r = n.x, t.preventDefault()) : e.isScrolling = !0 : 90 - o < h.touchAngle || e.isTouching ? (e.isTouching = !0, r = n.y, t.preventDefault()) : e.isScrolling = !0, a.scrollPixel(r * h.touchRatio);
          }
        },
        handleTouchEnd: function (t) {
          if (a.touchStatus.isTouchStart) {
            var e = a.index,
                i = a.slideSize,
                s = a.touchStatus,
                n = Date.now() - s.touchStartTime,
                o = d(r, a.isHorizontal) - s.startOffset;
            r.style.transition = "transform ease " + h.speed + "ms", n > a.config.longSwipesMs ? Math.abs(o) >= i * h.longSwipesRatio ? a.scroll(0 < o ? e - 1 : e + 1, !0) : a.scroll(e, !0) : 0 == o ? a.scroll(e, !0) : a.scroll(0 < o ? e - 1 : e + 1, !0), a.initTouchStatus();
          }
        },
        handleWheel: function (t) {
          var e = a.index,
              i = a.wheelStatus,
              s = t.deltaY;
          (0 < Math.abs(s) - Math.abs(i.wheelDelta) || !i.wheeling) && Math.abs(s) >= h.mousewheel.sensitivity && a.scroll(0 < s ? e - 1 : e + 1), i.wheelDelta = s, clearTimeout(i.wheelingTimer), i.wheeling = !0, i.wheelingTimer = setTimeout(function () {
            a.initWheelStatus();
          }, 200), t.preventDefault(), t.stopPropagation();
        }
      };
    }, t.attachListener = function () {
      var t = this.$el,
          e = this.config,
          i = this.supportTouch,
          s = this.listeners,
          n = s.handleTouchStart,
          o = s.handleTouchMove,
          r = s.handleTouchEnd,
          a = s.handleWheel;
      i ? (t.addEventListener("touchstart", n, {
        passive: e.passiveListeners,
        capture: !1
      }, !1), t.addEventListener("touchmove", o), t.addEventListener("touchend", r), t.addEventListener("touchcancel", r)) : (t.addEventListener("mousedown", n), document.addEventListener("mousemove", o), document.addEventListener("mouseup", r)), e.mousewheel && t.addEventListener("wheel", a);
    }, t.detachListener = function () {
      var t = this.$el,
          e = this.listeners,
          i = e.handleTouchStart,
          s = e.handleTouchMove,
          n = e.handleTouchEnd,
          o = e.handleWheel;
      t.removeEventListener("touchstart", i), t.removeEventListener("touchmove", s), t.removeEventListener("touchend", n), t.removeEventListener("touchcancel", n), t.removeEventListener("mousedown", i), document.removeEventListener("mousemove", s), document.removeEventListener("mouseup", n), t.removeEventListener("wheel", o);
    }, s.formatConfig = function (t) {
      void 0 === t && (t = {});
      return t.mousewheel && (t.mousewheel = e({
        invert: !1,
        sensitivity: 1
      }, t.mousewheel)), e({}, {
        direction: "horizontal",
        touchRatio: 1,
        touchAngle: 45,
        longSwipesRatio: .5,
        initialSlide: 0,
        loop: !1,
        mousewheel: !1,
        pagination: !1,
        passiveListeners: !0,
        resistance: !0,
        resistanceRatio: .85,
        speed: 300,
        longSwipesMs: 300,
        intermittent: 0,
        spaceBetween: 0,
        slidePrevClass: "swiper-slide-prev",
        slideNextClass: "swiper-slide-next",
        slideActiveClass: "swiper-slide-active",
        slideClass: "swiper-slide",
        wrapperClass: "swiper-wrapper",
        touchStartPreventDefault: !0,
        touchStartForcePreventDefault: !1,
        touchMoveStopPropagation: !1,
        excludeElements: []
      }, {}, t);
    }, t.transform = function (t) {
      this.$wrapper.style.transform = this.isHorizontal ? "translate3d(" + t + "px, 0, 0)" : "translate3d(0, " + t + "px, 0)";
    }, t.scroll = function (t, e) {
      var i = this;

      if (void 0 === t && (t = 0), void 0 === e && (e = !1), !this.scrolling || e) {
        this.emit("before-slide", this.index, this);
        var s = this.config,
            n = this.minIndex,
            o = this.maxIndex,
            r = (t = t < n ? n : o < t ? o : t) * this.boxSize;
        this.scrolling = !0, this.transform(-r);
        var a = this.$list[t],
            h = this.$list[t - 1],
            l = this.$list[t + 1];
        a && (c(a, s.slideActiveClass), u(a, [s.slidePrevClass, s.slideNextClass])), h && (c(h, s.slidePrevClass), u(h, [s.slideActiveClass, s.slideNextClass])), l && (c(l, s.slideNextClass), u(l, [s.slideActiveClass, s.slidePrevClass])), this.index = t, setTimeout(function () {
          i.scrolling = !1, i.emit("after-slide", t, i);
        }, this.config.speed + this.config.intermittent);
      }
    }, t.scrollPixel = function (t) {
      var e = t.toExponential().split("e")[1],
          i = e <= 0 ? Math.pow(10, -(e - 1)) : 1;
      this.config.resistance && (0 < t && 0 === this.index ? t -= Math.pow(t * i, this.config.resistanceRatio) / i : t < 0 && this.index === this.maxIndex && (t += Math.pow(-t * i, this.config.resistanceRatio) / i));
      var s = d(this.$wrapper, this.isHorizontal);
      this.transform(s + t);
    }, t.initTouchStatus = function () {
      this.touchStatus = {
        touchTracks: [],
        startOffset: 0,
        touchStartTime: 0,
        isTouchStart: !1,
        isScrolling: !1,
        isTouching: !1
      };
    }, t.initWheelStatus = function () {
      this.wheelStatus = {
        wheeling: !1,
        wheelDelta: 0,
        wheelingTimer: !1
      };
    }, t.update = function () {
      var e = this,
          t = this.$el,
          i = this.$wrapper,
          s = this.index,
          n = this.config,
          o = i.style,
          r = "horizontal" === n.direction;
      this.isHorizontal = r, this.$list = [].slice.call(t.getElementsByClassName(n.slideClass)), this.minIndex = 0, this.maxIndex = this.$list.length - 1, this.slideSize = r ? t.offsetWidth : t.offsetHeight, this.boxSize = this.slideSize + n.spaceBetween, this.$list.forEach(function (t) {
        t.style[r ? "width" : "height"] = e.slideSize + "px", t.style[r ? "margin-right" : "margin-bottom"] = n.spaceBetween + "px";
      }), t.style.overflow = "hidden", o.willChange = "transform", o.transition = "transform ease " + this.config.speed + "ms", o[r ? "width" : "height"] = this.boxSize * this.$list.length + "px", o.display = "flex", o.flexDirection = r ? "row" : "column", this.transform(-s * this.boxSize);
    }, t.destroy = function () {
      var t = this.$el,
          e = this.$wrapper,
          i = this.config.slideActiveClass;
      this.emit("before-destroy", this), this.$list.forEach(function (t) {
        t.removeAttribute("style"), u(t, [i]);
      }), e.removeAttribute("style"), t.removeAttribute("style"), this.detachListener(), this.emit("after-destroy", this), this.$el = null, this.$list = [], this.$wrapper = null, this.eventHub = {}, this.config = s.formatConfig();
    }, s;
  }();
});
},{}],"or4r":[function(require,module,exports) {
var global = arguments[3];
/**
 * lodash (Custom Build) <https://lodash.com/>
 * Build: `lodash modularize exports="npm" -o ./`
 * Copyright jQuery Foundation and other contributors <https://jquery.org/>
 * Released under MIT license <https://lodash.com/license>
 * Based on Underscore.js 1.8.3 <http://underscorejs.org/LICENSE>
 * Copyright Jeremy Ashkenas, DocumentCloud and Investigative Reporters & Editors
 */

/** Used as the `TypeError` message for "Functions" methods. */
var FUNC_ERROR_TEXT = 'Expected a function';

/** Used as references for various `Number` constants. */
var NAN = 0 / 0;

/** `Object#toString` result references. */
var symbolTag = '[object Symbol]';

/** Used to match leading and trailing whitespace. */
var reTrim = /^\s+|\s+$/g;

/** Used to detect bad signed hexadecimal string values. */
var reIsBadHex = /^[-+]0x[0-9a-f]+$/i;

/** Used to detect binary string values. */
var reIsBinary = /^0b[01]+$/i;

/** Used to detect octal string values. */
var reIsOctal = /^0o[0-7]+$/i;

/** Built-in method references without a dependency on `root`. */
var freeParseInt = parseInt;

/** Detect free variable `global` from Node.js. */
var freeGlobal = typeof global == 'object' && global && global.Object === Object && global;

/** Detect free variable `self`. */
var freeSelf = typeof self == 'object' && self && self.Object === Object && self;

/** Used as a reference to the global object. */
var root = freeGlobal || freeSelf || Function('return this')();

/** Used for built-in method references. */
var objectProto = Object.prototype;

/**
 * Used to resolve the
 * [`toStringTag`](http://ecma-international.org/ecma-262/7.0/#sec-object.prototype.tostring)
 * of values.
 */
var objectToString = objectProto.toString;

/* Built-in method references for those with the same name as other `lodash` methods. */
var nativeMax = Math.max,
    nativeMin = Math.min;

/**
 * Gets the timestamp of the number of milliseconds that have elapsed since
 * the Unix epoch (1 January 1970 00:00:00 UTC).
 *
 * @static
 * @memberOf _
 * @since 2.4.0
 * @category Date
 * @returns {number} Returns the timestamp.
 * @example
 *
 * _.defer(function(stamp) {
 *   console.log(_.now() - stamp);
 * }, _.now());
 * // => Logs the number of milliseconds it took for the deferred invocation.
 */
var now = function() {
  return root.Date.now();
};

/**
 * Creates a debounced function that delays invoking `func` until after `wait`
 * milliseconds have elapsed since the last time the debounced function was
 * invoked. The debounced function comes with a `cancel` method to cancel
 * delayed `func` invocations and a `flush` method to immediately invoke them.
 * Provide `options` to indicate whether `func` should be invoked on the
 * leading and/or trailing edge of the `wait` timeout. The `func` is invoked
 * with the last arguments provided to the debounced function. Subsequent
 * calls to the debounced function return the result of the last `func`
 * invocation.
 *
 * **Note:** If `leading` and `trailing` options are `true`, `func` is
 * invoked on the trailing edge of the timeout only if the debounced function
 * is invoked more than once during the `wait` timeout.
 *
 * If `wait` is `0` and `leading` is `false`, `func` invocation is deferred
 * until to the next tick, similar to `setTimeout` with a timeout of `0`.
 *
 * See [David Corbacho's article](https://css-tricks.com/debouncing-throttling-explained-examples/)
 * for details over the differences between `_.debounce` and `_.throttle`.
 *
 * @static
 * @memberOf _
 * @since 0.1.0
 * @category Function
 * @param {Function} func The function to debounce.
 * @param {number} [wait=0] The number of milliseconds to delay.
 * @param {Object} [options={}] The options object.
 * @param {boolean} [options.leading=false]
 *  Specify invoking on the leading edge of the timeout.
 * @param {number} [options.maxWait]
 *  The maximum time `func` is allowed to be delayed before it's invoked.
 * @param {boolean} [options.trailing=true]
 *  Specify invoking on the trailing edge of the timeout.
 * @returns {Function} Returns the new debounced function.
 * @example
 *
 * // Avoid costly calculations while the window size is in flux.
 * jQuery(window).on('resize', _.debounce(calculateLayout, 150));
 *
 * // Invoke `sendMail` when clicked, debouncing subsequent calls.
 * jQuery(element).on('click', _.debounce(sendMail, 300, {
 *   'leading': true,
 *   'trailing': false
 * }));
 *
 * // Ensure `batchLog` is invoked once after 1 second of debounced calls.
 * var debounced = _.debounce(batchLog, 250, { 'maxWait': 1000 });
 * var source = new EventSource('/stream');
 * jQuery(source).on('message', debounced);
 *
 * // Cancel the trailing debounced invocation.
 * jQuery(window).on('popstate', debounced.cancel);
 */
function debounce(func, wait, options) {
  var lastArgs,
      lastThis,
      maxWait,
      result,
      timerId,
      lastCallTime,
      lastInvokeTime = 0,
      leading = false,
      maxing = false,
      trailing = true;

  if (typeof func != 'function') {
    throw new TypeError(FUNC_ERROR_TEXT);
  }
  wait = toNumber(wait) || 0;
  if (isObject(options)) {
    leading = !!options.leading;
    maxing = 'maxWait' in options;
    maxWait = maxing ? nativeMax(toNumber(options.maxWait) || 0, wait) : maxWait;
    trailing = 'trailing' in options ? !!options.trailing : trailing;
  }

  function invokeFunc(time) {
    var args = lastArgs,
        thisArg = lastThis;

    lastArgs = lastThis = undefined;
    lastInvokeTime = time;
    result = func.apply(thisArg, args);
    return result;
  }

  function leadingEdge(time) {
    // Reset any `maxWait` timer.
    lastInvokeTime = time;
    // Start the timer for the trailing edge.
    timerId = setTimeout(timerExpired, wait);
    // Invoke the leading edge.
    return leading ? invokeFunc(time) : result;
  }

  function remainingWait(time) {
    var timeSinceLastCall = time - lastCallTime,
        timeSinceLastInvoke = time - lastInvokeTime,
        result = wait - timeSinceLastCall;

    return maxing ? nativeMin(result, maxWait - timeSinceLastInvoke) : result;
  }

  function shouldInvoke(time) {
    var timeSinceLastCall = time - lastCallTime,
        timeSinceLastInvoke = time - lastInvokeTime;

    // Either this is the first call, activity has stopped and we're at the
    // trailing edge, the system time has gone backwards and we're treating
    // it as the trailing edge, or we've hit the `maxWait` limit.
    return (lastCallTime === undefined || (timeSinceLastCall >= wait) ||
      (timeSinceLastCall < 0) || (maxing && timeSinceLastInvoke >= maxWait));
  }

  function timerExpired() {
    var time = now();
    if (shouldInvoke(time)) {
      return trailingEdge(time);
    }
    // Restart the timer.
    timerId = setTimeout(timerExpired, remainingWait(time));
  }

  function trailingEdge(time) {
    timerId = undefined;

    // Only invoke if we have `lastArgs` which means `func` has been
    // debounced at least once.
    if (trailing && lastArgs) {
      return invokeFunc(time);
    }
    lastArgs = lastThis = undefined;
    return result;
  }

  function cancel() {
    if (timerId !== undefined) {
      clearTimeout(timerId);
    }
    lastInvokeTime = 0;
    lastArgs = lastCallTime = lastThis = timerId = undefined;
  }

  function flush() {
    return timerId === undefined ? result : trailingEdge(now());
  }

  function debounced() {
    var time = now(),
        isInvoking = shouldInvoke(time);

    lastArgs = arguments;
    lastThis = this;
    lastCallTime = time;

    if (isInvoking) {
      if (timerId === undefined) {
        return leadingEdge(lastCallTime);
      }
      if (maxing) {
        // Handle invocations in a tight loop.
        timerId = setTimeout(timerExpired, wait);
        return invokeFunc(lastCallTime);
      }
    }
    if (timerId === undefined) {
      timerId = setTimeout(timerExpired, wait);
    }
    return result;
  }
  debounced.cancel = cancel;
  debounced.flush = flush;
  return debounced;
}

/**
 * Checks if `value` is the
 * [language type](http://www.ecma-international.org/ecma-262/7.0/#sec-ecmascript-language-types)
 * of `Object`. (e.g. arrays, functions, objects, regexes, `new Number(0)`, and `new String('')`)
 *
 * @static
 * @memberOf _
 * @since 0.1.0
 * @category Lang
 * @param {*} value The value to check.
 * @returns {boolean} Returns `true` if `value` is an object, else `false`.
 * @example
 *
 * _.isObject({});
 * // => true
 *
 * _.isObject([1, 2, 3]);
 * // => true
 *
 * _.isObject(_.noop);
 * // => true
 *
 * _.isObject(null);
 * // => false
 */
function isObject(value) {
  var type = typeof value;
  return !!value && (type == 'object' || type == 'function');
}

/**
 * Checks if `value` is object-like. A value is object-like if it's not `null`
 * and has a `typeof` result of "object".
 *
 * @static
 * @memberOf _
 * @since 4.0.0
 * @category Lang
 * @param {*} value The value to check.
 * @returns {boolean} Returns `true` if `value` is object-like, else `false`.
 * @example
 *
 * _.isObjectLike({});
 * // => true
 *
 * _.isObjectLike([1, 2, 3]);
 * // => true
 *
 * _.isObjectLike(_.noop);
 * // => false
 *
 * _.isObjectLike(null);
 * // => false
 */
function isObjectLike(value) {
  return !!value && typeof value == 'object';
}

/**
 * Checks if `value` is classified as a `Symbol` primitive or object.
 *
 * @static
 * @memberOf _
 * @since 4.0.0
 * @category Lang
 * @param {*} value The value to check.
 * @returns {boolean} Returns `true` if `value` is a symbol, else `false`.
 * @example
 *
 * _.isSymbol(Symbol.iterator);
 * // => true
 *
 * _.isSymbol('abc');
 * // => false
 */
function isSymbol(value) {
  return typeof value == 'symbol' ||
    (isObjectLike(value) && objectToString.call(value) == symbolTag);
}

/**
 * Converts `value` to a number.
 *
 * @static
 * @memberOf _
 * @since 4.0.0
 * @category Lang
 * @param {*} value The value to process.
 * @returns {number} Returns the number.
 * @example
 *
 * _.toNumber(3.2);
 * // => 3.2
 *
 * _.toNumber(Number.MIN_VALUE);
 * // => 5e-324
 *
 * _.toNumber(Infinity);
 * // => Infinity
 *
 * _.toNumber('3.2');
 * // => 3.2
 */
function toNumber(value) {
  if (typeof value == 'number') {
    return value;
  }
  if (isSymbol(value)) {
    return NAN;
  }
  if (isObject(value)) {
    var other = typeof value.valueOf == 'function' ? value.valueOf() : value;
    value = isObject(other) ? (other + '') : other;
  }
  if (typeof value != 'string') {
    return value === 0 ? value : +value;
  }
  value = value.replace(reTrim, '');
  var isBinary = reIsBinary.test(value);
  return (isBinary || reIsOctal.test(value))
    ? freeParseInt(value.slice(2), isBinary ? 2 : 8)
    : (reIsBadHex.test(value) ? NAN : +value);
}

module.exports = debounce;

},{}],"WEtf":[function(require,module,exports) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
// device sniffing for mobile
var isMobile = {
  android: function android() {
    return navigator.userAgent.match(/Android/i);
  },
  blackberry: function blackberry() {
    return navigator.userAgent.match(/BlackBerry/i);
  },
  ios: function ios() {
    return navigator.userAgent.match(/iPhone|iPad|iPod/i);
  },
  opera: function opera() {
    return navigator.userAgent.match(/Opera Mini/i);
  },
  windows: function windows() {
    return navigator.userAgent.match(/IEMobile/i);
  },
  any: function any() {
    return isMobile.android() || isMobile.blackberry() || isMobile.ios() || isMobile.opera() || isMobile.windows();
  }
};
var _default = isMobile;
exports.default = _default;
},{}],"v9Q8":[function(require,module,exports) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
var fallbackData = [{
  image: '2018_02_stand-up',
  url: '2018/02/stand-up',
  hed: 'The Structure of Stand-Up Comedy'
}, {
  image: '2018_04_birthday-paradox',
  url: '2018/04/birthday-paradox',
  hed: 'The Birthday Paradox Experiment'
}, {
  image: '2018_11_boy-bands',
  url: '2018/11/boy-bands',
  hed: 'Internet Boy Band Database'
}, {
  image: '2018_08_pockets',
  url: '2018/08/pockets',
  hed: 'Women’s Pockets are Inferior'
}];
var storyData = null;

function loadJS(src, cb) {
  var ref = document.getElementsByTagName('script')[0];
  var script = document.createElement('script');
  script.src = src;
  script.async = true;
  ref.parentNode.insertBefore(script, ref);

  if (cb && typeof cb === 'function') {
    script.onload = cb;
  }

  return script;
}

function loadStories(cb) {
  var request = new XMLHttpRequest();
  var v = Date.now();
  var url = "https://pudding.cool/assets/data/stories.json?v=".concat(v);
  request.open('GET', url, true);

  request.onload = function () {
    if (request.status >= 200 && request.status < 400) {
      var data = JSON.parse(request.responseText);
      cb(data);
    } else cb(fallbackData);
  };

  request.onerror = function () {
    return cb(fallbackData);
  };

  request.send();
}

function createLink(d) {
  return "\n\t<a class='footer-recirc__article' href='https://pudding.cool/".concat(d.url, "' target='_blank'>\n\t\t<img class='article__img' src='https://pudding.cool/common/assets/thumbnails/640/").concat(d.image, ".jpg' alt='").concat(d.hed, "'>\n\t\t<p class='article__headline'>").concat(d.hed, "</p>\n\t</a>\n\t");
}

function recircHTML() {
  var url = window.location.href;
  var html = storyData.filter(function (d) {
    return !url.includes(d.url);
  }).slice(0, 4).map(createLink).join('');
  d3.select('.pudding-footer .footer-recirc__articles').html(html);
}

function init() {
  loadStories(function (data) {
    storyData = data;
    recircHTML();
  });
}

var _default = {
  init: init
};
exports.default = _default;
},{}],"f0mE":[function(require,module,exports) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

/* global d3 */
var $section = d3.select('[data-js="images"');
var $figure = $section.select('[data-js="images__figure"');

function resize() {}

function slide() {
  $figure.selectAll('img').transition().duration(0).delay(function (d, i) {
    return i * 750;
  }).on('end', function (d, i, n) {
    var $n = d3.select(n[i]);
    var top = $n.attr('data-top');
    var left = $n.attr('data-left');
    $n.style('top', top).style('left', left); // $n.classed('is-visible', true);
  });
}

function init() {
  $figure.selectAll('img').each(function (d, i, n) {
    var top = d3.format('%')(0.4 + Math.random() * 0.2);
    var left = d3.format('%')(0.2 + Math.random() * 0.6);
    d3.select(n[i]).attr('data-top', top).attr('data-left', left);
  });
}

var _default = {
  init: init,
  resize: resize,
  slide: slide
};
exports.default = _default;
},{}],"Pybl":[function(require,module,exports) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

/* global d3 */
var $section = d3.select('[data-js="people"');
var $figure = $section.select('[data-js="people__figure"');

function resize() {}

function slide() {
  $figure.selectAll('img').transition().duration(0).delay(function (d, i) {
    return i * 500;
  }).on('end', function (d, i, n) {
    var $n = d3.select(n[i]);
    var top = $n.attr('data-top');
    var left = $n.attr('data-left');
    $n.style('top', top).style('left', left); // $n.classed('is-visible', true);
  });
}

function init() {
  $figure.selectAll('img').each(function (d, i, n) {
    var top = d3.format('%')(0.4 + Math.random() * 0.2);
    var left = d3.format('%')(0.2 + Math.random() * 0.6);
    d3.select(n[i]).attr('data-top', top).attr('data-left', left);
  });
}

var _default = {
  init: init,
  resize: resize,
  slide: slide
};
exports.default = _default;
},{}],"xZJw":[function(require,module,exports) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = loadData;

/* global d3 */

/* usage
	import loadData from './load-data'
	
	loadData('file.csv').then(result => {
		console.log(result);
	}).catch(console.error);

	loadData(['file1.csv', 'file2.json]).then(result => {
		console.log(result);
	}).catch(console.error);
*/
function loadFile(file) {
  return new Promise(function (resolve, reject) {
    var ext = file.split('.').pop();
    if (ext === 'csv') d3.csv("assets/data/".concat(file)).then(resolve).catch(reject);else if (ext === 'json') d3.json("assets/data/".concat(file)).then(resolve).catch(reject);else reject(new Error("unsupported file type for: ".concat(file)));
  });
}

function loadData(files) {
  if (typeof files === 'string') return loadFile(files);
  var loads = files.map(loadFile);
  return Promise.all(loads);
}
},{}],"X1gf":[function(require,module,exports) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var _loadData = _interopRequireDefault(require("./load-data"));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(source, true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(source).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

var $section = d3.select('[data-js="category"');
var $graphic = $section.select('[data-js="category__graphic"');
var $figure = $graphic.select('[data-js="graphic__figure"');
var BP = 960;
var MOBILE_W = 240;
var mobile = false;
var pageH = 0;
var pageW = 0;
var other = ['Copywriting', 'Incorrect Statement', 'Low-quality Product', 'Inappropriate Animal Care', 'Plagiarism'];

function adjustSummary() {
  var $p = d3.select(this);
  var $s = $p.select('.person__summary');
  var top = 'auto';
  var bottom = 'auto';
  var left = 'auto';
  var right = 'auto';

  if (mobile) {
    var pbox = $p.node().getBoundingClientRect();
    var sbox = $s.node().getBoundingClientRect(); // top / height

    var y2 = sbox.height + sbox.top;
    if (y2 > pageH) bottom = '100%';else top = '100%';
    var center = pbox.left + pbox.width / 2;

    if (center > pageW / 2) {
      // name is on right half
      left = 'auto';
      var off = pbox.right - MOBILE_W;
      right = "".concat(off < 16 ? off : 0, "px");
    } else {
      // name is on left half
      right = 'auto';

      var _off = pbox.left + MOBILE_W - pageW;

      left = "".concat(_off > 16 ? -_off : 0, "px");
    }

    $s.style('top', top);
    $s.style('bottom', bottom);
    $s.style('left', left);
    $s.style('right', right);
  } else {
    var sNode = $s.node();
    sNode.removeAttribute('top');
    sNode.removeAttribute('bottom');
    sNode.removeAttribute('left');
    sNode.removeAttribute('right');
  }
}

function resize() {
  pageH = window.innerHeight;
  pageW = $section.node().offsetWidth;
  mobile = pageW < BP;
  $figure.selectAll('.person').each(adjustSummary);
}

function setup(people) {
  var data = people.filter(function (d) {
    return d.remove_flag === 'FALSE';
  }).map(function (d) {
    return _objectSpread({}, d, {
      cat: other.includes(d.controversy_type) ? 'Miscellaneous' : d.controversy_type
    });
  });
  var nested = d3.nest().key(function (d) {
    return d.cat;
  }).entries(data).map(function (d) {
    return _objectSpread({}, d, {
      values: d.values.concat([{
        name: d.key,
        label: true,
        cat: d.values[0].cat
      }])
    });
  });
  nested.sort(function (a, b) {
    return d3.descending(a.values.length, b.values.length);
  });
  var $c = $figure.selectAll('.controversy').data(nested).join('div').attr('class', 'controversy');
  var $p = $c.selectAll('.person').data(function (d) {
    return d.values;
  }).join('div').attr('class', function (d) {
    return "person ".concat(d.label ? 'is-label' : '', " ").concat(d.beauty ? 'is-beauty' : '');
  });
  $p.append('p').attr('class', 'person__name').text(function (d) {
    return d.name;
  });
  $p.append('p').attr('class', 'person__summary').classed('is-flip', function (d) {
    return ['Miscellaneous', 'Exploiting Audience'].includes(d.cat);
  }).text(function (d) {
    return d.controversy_summary;
  });
  resize();
}

function slide(value) {
  $figure.selectAll('.is-beauty').classed('is-active', value === 'beauty');

  if (value === 'insensitive') {
    $figure.selectAll('.person').classed('is-visible', function (d) {
      return d.cat === 'Insensitive Video';
    }).classed('is-mark', function (d) {
      return d.name === 'Logan Paul';
    });
  } else if (value === 'racist') {
    $figure.selectAll('.person').classed('is-visible', function (d) {
      return d.cat === 'Racist Comments';
    }).classed('is-mark', function (d) {
      return d.name === 'Laura Lee';
    });
  } else if (value === 'misc') {
    $figure.selectAll('.person').classed('is-visible', function (d) {
      return d.cat === 'Miscellaneous';
    }).classed('is-mark', function (d) {
      return d.name === 'Jenna Marbles';
    });
  } else $figure.selectAll('.person').classed('is-visible', true).classed('is-mark', false);
}

function init() {
  (0, _loadData.default)('people.csv').then(setup);
}

var _default = {
  init: init,
  resize: resize,
  slide: slide
};
exports.default = _default;
},{"./load-data":"xZJw"}],"ppRm":[function(require,module,exports) {
function _toConsumableArray(arr) { return _arrayWithoutHoles(arr) || _iterableToArray(arr) || _nonIterableSpread(); }

function _nonIterableSpread() { throw new TypeError("Invalid attempt to spread non-iterable instance"); }

function _iterableToArray(iter) { if (Symbol.iterator in Object(iter) || Object.prototype.toString.call(iter) === "[object Arguments]") return Array.from(iter); }

function _arrayWithoutHoles(arr) { if (Array.isArray(arr)) { for (var i = 0, arr2 = new Array(arr.length); i < arr.length; i++) { arr2[i] = arr[i]; } return arr2; } }

/* global d3 */

/*
 USAGE (example: line chart)
 1. c+p this template to a new file (line.js)
 2. change puddingChartName to puddingChartLine
 3. in graphic file: import './pudding-chart/line'
 4a. const charts = d3.selectAll('.thing').data(data).puddingChartLine();
 4b. const chart = d3.select('.thing').datum(datum).puddingChartLine();
*/
d3.selection.prototype.puddingChartLine = function init(options) {
  function createChart(el) {
    var BP = 480; // dom elements

    var $chart = d3.select(el);
    var $svg = null;
    var $axis = null;
    var $vis = null;
    var $label = null; // data

    var extentY = options.extentY,
        label = options.label,
        comp = options.comp;

    var _data = $chart.datum();

    var shouldShrink = false;
    var _fraction = 0;
    var _offset = 0;
    var _focus = [];
    var _highlight = null;
    var showBeauty = true;
    var showCluster = false;
    var _pre = true;
    var mobile = false;
    var endLabel = label.includes('Apology'); // dimensions

    var width = 0;
    var height = 0;
    var marginTop = 16;
    var marginBottom = 16;
    var marginLeft = 14;
    var marginRight = 28;
    var DUR = 500;
    var LABEL_SIZE = 12;
    var EASE = d3.easeCubicInOut; // scales

    var scaleX = d3.scaleLinear();
    var scaleY = d3.scaleLog().domain(extentY); // helper functions

    function enterPerson($e) {
      var $person = $e.append('g').attr('class', function (d) {
        var b = d.beauty ? 'is-beauty' : '';
        var cluster = "".concat(d.growth_delta).replace('-', 'neg');
        var g = "growth--".concat(endLabel ? d.growth_post : d.growth_pre);
        var c = "cluster--".concat(cluster);
        return "person ".concat(g, " ").concat(c, " ").concat(b);
      }).attr('data-name', function (d) {
        return d.name;
      });
      $person.append('path').attr('class', 'path--bg');
      $person.append('path').attr('class', 'path--fg');
      $person.append('text').text(function (d) {
        return d.name;
      });
      return $person;
    }

    var Chart = {
      // called once at start
      init: function init() {
        $svg = $chart.append('svg').attr('class', 'pudding-chart'); // create axis

        $axis = $svg.append('g').attr('class', 'g-axis'); // setup viz group

        $vis = $svg.append('g').attr('class', 'g-vis');
        $label = $svg.append('g').attr('class', 'g-label');
        $axis.append('g').attr('class', 'axis--y axis--y--bg');
        $axis.append('g').attr('class', 'axis--y axis--y--fg');
        $label.append('text').attr('class', 'text-comp text-comp--bg').text(comp).attr('x', -LABEL_SIZE / 2).attr('y', -LABEL_SIZE / 2).attr('text-anchor', 'end').style('font-size', LABEL_SIZE);
        $label.append('text').attr('class', 'text-comp text-comp--fg').text(comp).attr('x', -LABEL_SIZE / 2).attr('y', -LABEL_SIZE / 2).attr('text-anchor', 'end').style('font-size', LABEL_SIZE);
        $label.append('text').attr('class', 'text-label').text(label).attr('x', 0).attr('y', -LABEL_SIZE / 2).attr('text-anchor', endLabel ? 'end' : 'start').style('font-size', LABEL_SIZE);
      },
      // on resize, update new dimensions
      resize: function resize() {
        // defaults to grabbing dimensions from container element
        var w = $chart.node().offsetWidth;
        var h = $chart.node().offsetHeight;
        var factor = shouldShrink ? _fraction : 1;
        mobile = w < BP; // marginLeft = Math.floor(
        //   Chart.getDayCount() * MARGIN_FACTOR * w * factor
        // );
        // marginRight = marginLeft;

        width = w * factor - marginLeft - marginRight;
        height = h - marginTop - marginBottom;
        scaleX.range([0, width]);
        scaleY.range([height, 0]);
        $svg.style('margin-left', d3.format('%')(_offset));
        return Chart;
      },
      // update scales and render chart
      render: function render() {
        var _ref;

        var flat = (_ref = []).concat.apply(_ref, _toConsumableArray(_data.map(function (d) {
          return d.values;
        }))).map(function (d) {
          return d.days;
        });

        var extentX = d3.extent(flat);
        scaleX.domain(extentX);
        $svg.transition().duration(DUR).ease(EASE).attr('width', width + marginLeft + marginRight).attr('height', height + marginTop + marginBottom); // const axisY = endLabel ? d3.axisLeft(scaleY) : d3.axisRight(scaleY);

        var axisY = d3.axisRight(scaleY);
        axisY.tickValues([0.5, 1, 2]) // .tickSize(endComp ? -width : width)
        .tickSize(width).tickFormat(function (d) {
          return "".concat(d, "x").replace('0', '');
        });
        $axis.select('.axis--y--bg').transition().duration(DUR).ease(EASE).call(axisY);
        $axis.select('.axis--y--fg').transition().duration(DUR).ease(EASE).call(axisY); // offset chart for margins

        $axis.transition().duration(DUR).ease(EASE).attr('transform', "translate(".concat(marginLeft, ", ").concat(marginTop, ")"));
        $vis.transition().duration(DUR).ease(EASE).attr('transform', "translate(".concat(marginLeft, ", ").concat(marginTop, ")"));
        $label.transition().duration(DUR).ease(EASE).attr('transform', "translate(".concat(marginLeft, ", ").concat(marginTop, ")"));
        $label.selectAll('.text-comp').text(mobile && !_pre ? '' : comp).transition().duration(DUR).ease(EASE).attr('transform', "translate(".concat(width, ", ").concat(scaleY(1), ")"));
        $label.select('.text-label').text(mobile && !_pre ? label.replace('Controversy', '') : label).transition().duration(DUR).ease(EASE).attr('transform', "translate(".concat(endLabel ? width : 0, ", ").concat(height, ")")).style('font-size', "".concat(mobile ? 10 : 12, "px"));
        var generateLine = d3.line() // .curve(d3.curveMonotoneX)
        .x(function (d) {
          return scaleX(d.days);
        }).y(function (d) {
          return scaleY(d.value);
        });
        var $person = $vis.selectAll('.person').data(_data, function (d) {
          return d.key;
        }).join(enterPerson);
        $person.classed('is-focus', function (d) {
          return _focus.includes(d.name);
        }).classed('is-highlight', function (d) {
          return _highlight === d.name;
        }).classed('is-beauty', function (d) {
          if (showBeauty) return d.beauty;
          return _focus.includes(d.name) && d.beauty;
        }).classed('is-cluster', !showBeauty && !_focus.length && showCluster).classed('is-focus-cluster', function (d) {
          return showCluster && _focus.includes(d.name);
        });
        $person.sort(function (a, b) {
          return d3.ascending(a.name === _highlight, b.name === _highlight) || d3.ascending(_focus.includes(a.name), _focus.includes(b.name));
        });

        if (showCluster) {
          $person.sort(function (a, b) {
            return d3.ascending(a.name === _highlight, b.name === _highlight) || d3.ascending(_focus.includes(a.name), _focus.includes(b.name)) || d3.ascending(a.growth_delta < -2 || a.growth_delta > 0, b.growth_delta < -2 || b.growth_delta > 0);
          });
        }

        $person.select('.path--bg').datum(function (d) {
          return d.values;
        }).transition().duration(DUR).ease(EASE).attr('d', generateLine);
        $person.select('.path--fg').datum(function (d) {
          return d.values;
        }).transition().duration(DUR).ease(EASE).attr('d', generateLine);
        return Chart;
      },
      // get / set data
      data: function data(val) {
        if (!arguments.length) return _data;
        _data = val;
        $chart.datum(_data);
        return Chart;
      },
      // get day count
      getDayCount: function getDayCount() {
        return d3.max(_data, function (d) {
          return d.values.length;
        });
      },
      shrink: function shrink(val) {
        shouldShrink = val;
        return Chart;
      },
      fraction: function fraction(val) {
        if (!arguments.length) return _fraction;
        _fraction = val;
        return Chart;
      },
      offset: function offset(val) {
        if (!arguments.length) return _offset;
        _offset = val;
        return Chart;
      },
      focus: function focus(val) {
        if (val) _focus = val;else _focus = [];
        return Chart;
      },
      beauty: function beauty(val) {
        showBeauty = val;
        return Chart;
      },
      cluster: function cluster(val) {
        showCluster = val;
        return Chart;
      },
      highlight: function highlight(val) {
        _highlight = val;
        return Chart;
      },
      pre: function pre(val) {
        _pre = val;
        return Chart;
      }
    };
    Chart.init();
    return Chart;
  } // create charts


  var charts = this.nodes().map(createChart);
  return charts.length > 1 ? charts : charts.pop();
};
},{}],"IClS":[function(require,module,exports) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var _loadData = _interopRequireDefault(require("./load-data"));

require("./pudding-chart/impact-line");

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _slicedToArray(arr, i) { return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _nonIterableRest(); }

function _nonIterableRest() { throw new TypeError("Invalid attempt to destructure non-iterable instance"); }

function _iterableToArrayLimit(arr, i) { if (!(Symbol.iterator in Object(arr) || Object.prototype.toString.call(arr) === "[object Arguments]")) { return; } var _arr = []; var _n = true; var _d = false; var _e = undefined; try { for (var _i = arr[Symbol.iterator](), _s; !(_n = (_s = _i.next()).done); _n = true) { _arr.push(_s.value); if (i && _arr.length === i) break; } } catch (err) { _d = true; _e = err; } finally { try { if (!_n && _i["return"] != null) _i["return"](); } finally { if (_d) throw _e; } } return _arr; }

function _arrayWithHoles(arr) { if (Array.isArray(arr)) return arr; }

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(source, true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(source).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

var BP = 480;
var mobile = false;
var chartPre = null;
var chartPost = null;
var $section = d3.select('[data-js="impact"');
var $graphic = $section.select('[data-js="impact__graphic"');
var $zone = $graphic.select('[data-js="graphic__zone"');
var $figurePre = $graphic.select('[data-js="figure--pre"');
var $figurePost = $graphic.select('[data-js="figure--post"');
var $select = $graphic.select('[data-js="graphic__select"');

function handleSelectChange() {
  var name = this.value;
  if (name === 'Highlight') chartPre.highlight().render();
  chartPre.highlight(name).render();
  chartPost.highlight(name).render();
}

function updateChartDimensions() {
  mobile = $section.node().offsetWidth < BP;
  var daysPre = chartPre.getDayCount();
  var daysPost = chartPost.getDayCount();
  var daysZone = Math.floor(daysPre * (mobile ? 0.05 : 0.2));
  var total = daysPre + daysPost + daysZone;
  var perPre = daysPre / total;
  var perPost = daysPost / total;
  var perZone = daysZone / total;
  chartPre.fraction(perPre);
  chartPost.fraction(perPost).offset(perPre + perZone);
  $zone.style('width', d3.format('%')(perZone)).style('left', d3.format('%')(perPre)); // const gtc = `${daysPre}fr ${zone}fr ${daysPost}fr`;
  // $graphic.style('grid-template-columns', gtc);
}

function resize() {
  updateChartDimensions();
}

function slide(value) {
  // reset option
  $select.selectAll('option').property('selected', function (d) {
    return d.name === 'Highlight';
  });
  var isPre = ['pre-setup', 'pre-result', 'pre-example', 'post-setup'].includes(value);
  var ignoreBeauty = ['post-positive', 'post-negative', 'post-cluster'].includes(value);
  $select.classed('is-visible', !isPre);
  $figurePost.classed('is-visible', !isPre);
  $zone.classed('is-visible', !isPre);
  chartPre.shrink(value === 'post-result');
  chartPre.beauty(!ignoreBeauty);
  chartPost.beauty(!ignoreBeauty);
  chartPre.highlight();
  chartPost.highlight();
  chartPre.pre(isPre);
  if (value === 'pre-example') chartPre.focus(['Jake Paul']).render();else if (value === 'post-positive') {
    chartPre.cluster(true).focus(['Gabriel Zamora']).render();
    chartPost.cluster(true).focus(['Gabriel Zamora']).render();
  } else if (value === 'post-negative') {
    chartPre.cluster(true).focus(['Laura Lee']).render();
    chartPost.cluster(true).focus(['Laura Lee']).render();
  } else if (value === 'post-cluster') {
    chartPre.cluster(true).render();
    chartPost.cluster(true).render();
  } else {
    chartPre.focus().cluster().render();
    chartPost.focus().cluster().render();
  }
  var resizePre = ['pre-example', 'post-result'].includes(value);
  if (resizePre) chartPre.resize().render();
}

function cleanData(data, pre) {
  var factor = pre ? -1 : 1;
  var side = pre ? 'pre' : 'post';
  return data.map(function (d) {
    return _objectSpread({}, d, {
      days: +d.days * factor,
      value: +d.value,
      side: side
    });
  });
}

function setupSelect(data) {
  $select.selectAll('option').data([{
    name: 'Highlight'
  }].concat(data)).join('option').text(function (d) {
    return d.name;
  });
  $select.on('change', handleSelectChange);
}

function setup(_ref) {
  var _ref2 = _slicedToArray(_ref, 3),
      people = _ref2[0],
      pre = _ref2[1],
      post = _ref2[2];

  var dataPeople = people.filter(function (d) {
    return d.remove_flag === 'FALSE';
  }).map(function (d) {
    return _objectSpread({}, d, {
      growth_delta: +d.growth_delta
    });
  });
  var dataPre = cleanData(pre, true);
  var dataPost = cleanData(post, false);
  var joined = dataPre.concat(dataPost);
  var extentY = d3.extent(joined, function (d) {
    return d.value;
  });
  var nestedPre = d3.nest().key(function (d) {
    return d.id;
  }).entries(dataPre).map(function (d) {
    return _objectSpread({}, d, {
      cluster: d.values[0].cluster
    }, dataPeople.find(function (v) {
      return v.id === d.key;
    }));
  }).filter(function (d) {
    return d.id;
  });
  var nestedPost = d3.nest().key(function (d) {
    return d.id;
  }).entries(dataPost).map(function (d) {
    return _objectSpread({}, d, {
      cluster: d.values[0].cluster
    }, dataPeople.find(function (v) {
      return v.id === d.key;
    }));
  }).filter(function (d) {
    return d.id;
  });
  nestedPre.sort(function (a, b) {
    return d3.ascending(a.beauty, b.beauty);
  });
  nestedPost.sort(function (a, b) {
    return d3.ascending(a.beauty, b.beauty);
  });
  chartPre = $figurePre.datum(nestedPre).puddingChartLine({
    extentY: extentY,
    label: '90 Days Until Controversy',
    comp: 'Pre-Controversy Max'
  });
  chartPost = $figurePost.datum(nestedPost).puddingChartLine({
    extentY: extentY,
    label: '180 Days Since Apology',
    comp: 'Pre-Apology Max'
  });
  updateChartDimensions();
  chartPre.resize().render();
  chartPost.shrink(true).resize().render();
  setupSelect(dataPeople);
}

function init() {
  (0, _loadData.default)(['people.csv', 'pre.csv', 'post.csv']).then(setup);
}

var _default = {
  init: init,
  resize: resize,
  slide: slide
};
exports.default = _default;
},{"./load-data":"xZJw","./pudding-chart/impact-line":"ppRm"}],"oJIz":[function(require,module,exports) {
/*
 USAGE (example: line chart)
 1. c+p this template to a new file (line.js)
 2. change puddingChartName to puddingChartLine
 3. in graphic file: import './pudding-chart/line'
 4a. const charts = d3.selectAll('.thing').data(data).puddingChartLine();
 4b. const chart = d3.select('.thing').datum(datum).puddingChartLine();
*/
d3.selection.prototype.puddingChartBeeswarm = function init(options) {
  function createChart(el) {
    var $sel = d3.select(el);
    var data = $sel.datum(); // dimension stuff

    var width = 0;
    var height = 0;
    var radius = 0;
    var margin = 0;
    var sim = d3.forceSimulation(data); // scales

    var scaleX = d3.scaleLinear();
    var scaleY = d3.scaleLinear(); // dom elements

    var $svg = null;
    var $bees = null;
    var $bee = null;
    var $axis = null; // let $vis = null;
    // helper functions

    var Chart = {
      // called once at start
      init: function init() {
        $svg = $sel.append('svg').attr('class', 'pudding-chart');
        $bees = $sel.append('div').attr('class', 'bees'); // const $g = $svg.append("g");
        // offset chart for margins
        // $g.attr("transform", `translate(${margin}, ${margin})`);
        // setup viz group
        // $vis = $g.append("g").attr("class", "g-vis");
        // create axis

        $axis = $svg.append('g').attr('class', 'g-axis');
        $axis.append('line').attr('class', 'axis');
      },
      // on resize, update new dimensions
      resize: function resize(mobile) {
        // defaults to grabbing dimensions from container element
        var titleH = d3.select('#beeswarm .graphic__title').node().offsetHeight;
        width = $sel.node().parentElement.offsetWidth;
        height = $sel.node().parentElement.offsetHeight - titleH;
        radius = Math.floor(mobile ? 0.33 * width : 0.25 * height);
        margin = Math.floor(radius * 0.5);
        width -= margin * 2;
        height -= margin * 2;
        $sel.style('height', "".concat(height + margin * 2, "px"));
        $svg.attr('width', width + margin * 2).attr('height', height + margin * 2);
        $axis.select('.axis').attr('transform', "translate(".concat(margin, ", ").concat(margin, ")")).transition().attr('y1', mobile ? 0 : height / 2).attr('y2', mobile ? 0 + height : height / 2).attr('x1', mobile ? width / 2 : 0).attr('x2', mobile ? width / 2 : 0 + width);
        scaleX.range([0, width]);
        scaleY.range([height, 0]);
        $bees.style('top', "".concat(margin, "px")).style('left', "".concat(margin, "px"));
        sim.force('y-pos', mobile ? d3.forceY(function (node) {
          return scaleY(node.display);
        }).strength(function (node) {
          return node.beauty ? 1 : 0.5;
        }) : d3.forceY(height / 2).strength(function (node) {
          return node.beauty ? 1 : 0.5;
        })).force('x-pos', mobile ? d3.forceX(width / 2).strength(function (node) {
          return node.beauty ? 1 : 0.5;
        }) : d3.forceX(function (node) {
          return scaleX(node.display);
        }).strength(function (node) {
          return node.beauty ? 1 : 0.5;
        })).force('collide', d3.forceCollide(function (node) {
          return node.beauty ? radius / 1.95 : radius / 8;
        }));
        return Chart;
      },
      // update scales and render chart
      render: function render() {
        $bee = $bees.selectAll('.bee').data(data, function (d) {
          return d.name;
        }).join('div').attr('class', function (d) {
          return "bee ".concat(d.beauty ? 'is-beauty' : '');
        }).attr('data-js', function (d) {
          return "bee--".concat(d.name.replace(/\s/g, ''));
        }).style('background-image', function (d) {
          return d.beauty ? "url(\"assets/images/people/".concat(d.name.replace(/\s/g, ''), "@2x.jpg\")") : '';
        }).style('width', function (d) {
          return "".concat(d.beauty ? radius : radius / 4, "px");
        }).style('height', function (d) {
          return "".concat(d.beauty ? radius : radius / 4, "px");
        }).style('background-size', "".concat(1.15 * radius, "px")).style('top', function (d) {
          return d.beauty ? height / 2 : 0;
        }).style('left', function (d) {
          return d.beauty ? scaleX(d.display) : 0;
        });
        sim.alpha(0.4).on('tick', function () {
          $bee.style('left', function (d) {
            return "".concat(d.x, "px");
          }).style('top', function (d) {
            return "".concat(d.y, "px");
          });
        }).restart();
        return Chart;
      },
      getBees: function getBees() {
        return $bee;
      }
    };
    Chart.init();
    return Chart;
  } // create charts


  var charts = this.nodes().map(createChart);
  return charts.length > 1 ? charts : charts.pop();
};
},{}],"F0i1":[function(require,module,exports) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var _loadData = _interopRequireDefault(require("./load-data"));

require("./pudding-chart/beeswarm");

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(source, true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(source).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

var $body = d3.select('body');
var $section = d3.select('[data-js="beeswarm"]');
var $graphic = $section.select('[data-js="beeswarm__graphic"]');
var $figure = $graphic.selectAll('[data-js="graphic__figure"]');
var $chart = $graphic.selectAll('[data-js="graphic__chart"]');
var BP = 480;
var TITLE_H = 2.5 * 16;
var charts = [];
var mobile = false;

function slide(value) {
  var focusSlides = ['GabrielZamora', 'JeffreeStar', 'JamesCharles', 'JaclynHill', 'LauraLee'];
  mouseOutHandler();

  if (focusSlides.includes(value)) {
    var $els = d3.selectAll("[data-js=\"bee--".concat(value, "\""));
    highlightEl($els.node());
    $els.each(function (d) {
      hoverText(this, d);
    });
  }
}

function resize() {
  mobile = $body.node().offsetWidth < BP; // const h = d3.select('[data-type="text"] .slide__text').node().offsetHeight;

  var sz = mobile ? $section.node().offsetHeight - TITLE_H : Math.floor($section.node().offsetHeight / $chart.size());
  $chart.style('height', "".concat(sz, "px"));
  charts.forEach(function (chart) {
    chart.resize(mobile).render();
  });
}

function cleanData(data) {
  var clean = data.map(function (d) {
    return _objectSpread({}, d, {
      beauty: d.beauty === 'TRUE'
    });
  });
  var filtered = clean.filter(function (d) {
    return d.value !== 'NA';
  });
  return filtered;
}

function setupGraphics() {
  var $f = d3.select(this);
  var id = $f.attr('data-id');
  var file = "beeswarm--".concat(id, ".csv");
  (0, _loadData.default)(file).then(cleanData).then(function (data) {
    var chart = $f.datum(data).puddingChartBeeswarm();
    chart.resize(mobile).render();
    chart.getBees().nodes().forEach(setupHover);
    charts.push(chart);
  });
}

function setupHover(el) {
  d3.select(el).on('mouseover', mouseInHandler).on('mouseout', mouseOutHandler);
}

function mouseInHandler(data) {
  highlightEl(this);
  hoverText(this, data);
}

function mouseOutHandler() {
  d3.selectAll('.bee').transition().duration(250).ease(d3.easeCubicInOut).style('opacity', 1);
  d3.selectAll('[data-js="beeswarm__hovertext"]').transition().duration(250).ease(d3.easeCubicInOut).style('opacity', 0);
}

function hoverText(elem, data) {
  var $fig = elem.parentElement.parentElement;
  var id = $fig.getAttribute('data-id');
  var $hoverBox = d3.select("[data-id=\"beeswarm__hovertext_".concat(id, "\"]"));
  var bbox = $hoverBox.node().getBoundingClientRect();
  if (!mobile) $hoverBox.select('[data-js="beeswarm__hovertext__title"]').html(data.name);
  $hoverBox.select('[data-js="beeswarm__hovertext__content"]').html(data.value);
  var xoff = mobile ? bbox.width / 2 : data.display < 0.2 ? 0 : data.display < 0.8 ? bbox.width / 2 : bbox.width;
  var yoff = mobile ? -elem.offsetHeight * 1.75 : -elem.offsetHeight * 0.5;
  $hoverBox.classed('is-beauty', data.beauty).style('left', "".concat(data.x - xoff + elem.parentElement.offsetLeft, "px")).style('top', "".concat(data.y - yoff + elem.parentElement.offsetTop, "px")).transition().duration(250).ease(d3.easeCubicInOut).style('opacity', 1);
}

function highlightEl(elem) {
  var $dataAttr = d3.select(elem).attr('data-js');
  d3.selectAll('.bee').transition().duration(250).ease(d3.easeCubicInOut).style('opacity', 0.25);
  d3.selectAll("[data-js=".concat($dataAttr, "]")).transition().duration(250).ease(d3.easeCubicInOut).style('opacity', 1);
}

function init() {
  $figure.each(setupGraphics);
  resize();
  $graphic.classed('is-interactive', !$body.classed('is-mobile'));
}

var _default = {
  init: init,
  resize: resize,
  slide: slide
};
exports.default = _default;
},{"./load-data":"xZJw","./pudding-chart/beeswarm":"oJIz"}],"epB2":[function(require,module,exports) {
"use strict";

var _tinySwiper = _interopRequireDefault(require("tiny-swiper"));

var _lodash = _interopRequireDefault(require("lodash.debounce"));

var _isMobile = _interopRequireDefault(require("./utils/is-mobile"));

var _footer = _interopRequireDefault(require("./footer"));

var _graphicImages = _interopRequireDefault(require("./graphic-images"));

var _graphicPeople = _interopRequireDefault(require("./graphic-people"));

var _graphicCategory = _interopRequireDefault(require("./graphic-category"));

var _graphicImpact = _interopRequireDefault(require("./graphic-impact"));

var _graphicBeeswarm = _interopRequireDefault(require("./graphic-beeswarm"));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/* global d3 */
var $body = d3.select('body');
var $graphics = $body.select('.graphics');
var $slide = $body.selectAll('[data-js="slide"]');
var $slideText = $body.selectAll('[data-type="text"]');
var $section = $body.selectAll('section');
var $nerdButton = $body.select('[data-js="nerd-mode__button"]');
var $nerdSlide = $body.selectAll('[data-js="slide__nerd"]');
var $arrows = $body.select('[data-js="arrows"]');
var $introStart = $body.select('[data-js="intro__start"]');
var $arrowLeft = $body.select('[data-js="arrow--left"]');
var $arrowRight = $body.select('[data-js="arrow--right"]');
var $progress = $body.select('[data-js="progress__inner"]');
var SLIDE_COUNT = $slide.size();
var swiper = null;

function toggleNerd() {
  var $s = d3.select('.slide--active');
  var $n = $s.select('[data-js="slide__nerd"]');

  if ($n.size()) {
    var v = $n.classed('is-visible');
    $n.classed('is-visible', !v);
  }
}

function getSlideTextHeight() {
  var h = [];
  $slideText.each(function (d, i, n) {
    var $t = d3.select(n[i]).select('.slide__text');
    if ($t.size()) h.push($t.node().offsetHeight);
  });
  return Math.max.apply(Math, h);
}

function updateSwiper() {
  swiper.update();
}

function updateText() {
  var h = getSlideTextHeight();
  $graphics.style('height', "".concat(window.innerHeight - h, "px"));
  $slideText.select('.slide__text').style('height', "".concat(h, "px"));
}

function resize() {
  updateText();

  _graphicImages.default.resize();

  _graphicPeople.default.resize();

  _graphicCategory.default.resize();

  _graphicImpact.default.resize();

  _graphicBeeswarm.default.resize();

  updateSwiper();
}

function setupSwiper() {
  var index = 0;
  var containerEl = d3.select('[data-js="swiper"]').node();
  swiper = new _tinySwiper.default(containerEl, {
    wrapperClass: 'swiper__wrapper',
    slideClass: 'slide',
    slideNextClass: 'slide--next',
    slidePrevClass: 'slide--prev',
    slideActiveClass: 'slide--active'
  });
  swiper.on('after-slide', function (newIndex) {
    $nerdSlide.classed('is-visible', false);
    index = newIndex;
    var $s = $slide.filter(function (d, i) {
      return i === index;
    });
    var slide = $s.attr('data-slide');
    var trigger = $s.attr('data-trigger');
    var nerd = !!$s.attr('data-nerd');
    $nerdButton.classed('is-visible', nerd);
    $section.classed('is-visible', false);
    $progress.style('width', d3.format('%')(index / (SLIDE_COUNT - 1)));

    if (trigger) {
      d3.select("[data-js=\"".concat(trigger, "\"]")).classed('is-visible', true);
      if (trigger === 'category') _graphicCategory.default.slide(slide);
      if (trigger === 'impact') _graphicImpact.default.slide(slide);
      if (trigger === 'images') _graphicImages.default.slide(slide);
      if (trigger === 'people') _graphicPeople.default.slide(slide);
      if (trigger === 'beeswarm') _graphicBeeswarm.default.slide(slide);
    }
  });

  var advance = function advance(i) {
    if (i !== index) {
      index = i;
      swiper.scroll(index);
    }

    $arrowLeft.classed('is-visible', index > 0);
    $arrowRight.classed('is-visible', index < SLIDE_COUNT - 1);
  }; // arrow keys


  $body.on('keydown', function () {
    var key = d3.event.keyCode;
    var newIndex = index;
    if (key === 37) newIndex -= 1;else if (key === 39) newIndex += 1;
    newIndex = Math.max(0, Math.min(newIndex, SLIDE_COUNT - 1));
    advance(newIndex);
  });
  $nerdSlide.classed('is-loaded', true);
  $arrowLeft.on('click', function () {
    var newIndex = index - 1;
    newIndex = Math.max(0, newIndex);
    advance(newIndex);
  });
  $arrowRight.on('click', function () {
    var newIndex = index + 1;
    newIndex = Math.min(newIndex, SLIDE_COUNT - 1);
    advance(newIndex);
  });
}

function setupNerd() {
  $nerdButton.on('click', toggleNerd);
}

function init() {
  $body.style('height', window.innerHeight - 100); // add mobile class to body tag

  $body.classed('is-mobile', _isMobile.default.any());
  $arrows.classed('is-visible', true);
  $introStart.classed('is-visible', true); // setup resize event

  window.addEventListener('resize', (0, _lodash.default)(resize, 150)); // kick off graphic code

  updateText();

  _graphicImages.default.init();

  _graphicPeople.default.init();

  _graphicCategory.default.init();

  _graphicImpact.default.init();

  _graphicBeeswarm.default.init(); // setup swiper


  setupSwiper();
  updateSwiper();
  setupNerd(); // load footer stories

  _footer.default.init();
}

init();
},{"tiny-swiper":"cscv","lodash.debounce":"or4r","./utils/is-mobile":"WEtf","./footer":"v9Q8","./graphic-images":"f0mE","./graphic-people":"Pybl","./graphic-category":"X1gf","./graphic-impact":"IClS","./graphic-beeswarm":"F0i1"}]},{},["epB2"], null)
//# sourceMappingURL=/main.js.map